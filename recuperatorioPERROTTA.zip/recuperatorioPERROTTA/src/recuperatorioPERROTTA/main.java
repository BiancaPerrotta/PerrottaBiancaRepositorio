package recuperatorioPERROTTA;

import java.util.Random;
import java.util.Scanner;

public class main {
	public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Random rnd = new Random();
        boolean reiniciarPrograma = true;

        do {
            int filas, columnas;

            do {
                System.out.print("Ingrese el número de filas (entre 10 y 50): ");
                filas = scanner.nextInt();
            } while (filas < 10 || filas > 50);

            do {
                System.out.print("Ingrese el número de columnas (entre 10 y 50): ");
                columnas = scanner.nextInt();
            } while (columnas < 10 || columnas > 50);

            
            int[][] matriz = new int[filas][columnas];

            
            for (int i = 0; i < filas; i++) {
                for (int j = 0; j < columnas; j++) {
                    matriz[i][j] = (int) (rnd.nextDouble() * 90 + 10);
                }
            }

            
            System.out.println("Matriz generada:");
            mostrarMatriz(matriz);

            
            int[][] nuevaMatriz = new int[3][4];

            for (int i = 0; i < 12; i++) {
                int fila, columna;

                do {
                    System.out.print("Ingrese la fila (0-" + (filas - 1) + "): ");
                    fila = scanner.nextInt();
                } while (fila < 0 || fila >= filas);

                do {
                    System.out.print("Ingrese la columna (0-" + (columnas - 1) + "): ");
                    columna = scanner.nextInt();
                } while (columna < 0 || columna >= columnas || yaSeleccionado(nuevaMatriz, matriz[fila][columna]));

                nuevaMatriz[i / 4][i % 4] = matriz[fila][columna];
            }

            
            System.out.println("Matriz de 12 valores seleccionados:");
            mostrarMatriz(nuevaMatriz);

            
            int[] sumaColumnas = new int[4];
            for (int i = 0; i < 3; i++) {
                for (int j = 0; j < 4; j++) {
                    sumaColumnas[j] += nuevaMatriz[i][j];
                }
            }

            
            System.out.println("Suma de las columnas:");
            int columnaMaxima = 0;

            for (int i = 0; i < 4; i++) {
                System.out.println("Columna " + i + ": " + sumaColumnas[i]);

                if (sumaColumnas[i] > sumaColumnas[columnaMaxima]) {
                    columnaMaxima = i;
                }
            }

            System.out.println("La columna con la suma máxima es la columna " + columnaMaxima);

            
            System.out.print("¿Desea iniciar nuevamente la ejecución del programa? (SI/NO): ");
            String reiniciar = scanner.next();
            reiniciarPrograma = reiniciar.equalsIgnoreCase("SI");

        } while (reiniciarPrograma);

        System.out.println("Programa finalizado.");
    }

    
    private static void mostrarMatriz(int[][] matriz) {
        for (int[] fila : matriz) {
            for (int valor : fila) {
                System.out.print(valor + " ");
            }
            System.out.println();
        }
    }

    
    private static boolean yaSeleccionado(int[][] matrizOriginal, int valor) {
        for (int[] fila : matrizOriginal) {
            for (int elemento : fila) {
                if (elemento == valor) {
                    return true;
                }
            }
        }
        return false;
    }
}

	